package pasta;
use Moose;


###################################
#           ATTRIBUTES            #
###################################


has quantita => (
	is => 'rw',
	isa => 'Int',
	required => 1,
	default => 80,
	trigger => sub( ),
); 



###################################
#            METHODS              #
###################################


1;