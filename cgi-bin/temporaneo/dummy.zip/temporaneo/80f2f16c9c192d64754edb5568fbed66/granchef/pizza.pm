package pizza;
use Moose;


###################################
#           ATTRIBUTES            #
###################################


has asdfdsf => (
	is => 'rw',
	isa => 'array_ref',
	required => 1,
	default => ,
	trigger => sub( ),
); 

has pomodoro => (
	is => 'rw',
	isa => 'Int',
	required => 1,
	default => ,
	trigger => sub( ),
); 



###################################
#            METHODS              #
###################################


1;